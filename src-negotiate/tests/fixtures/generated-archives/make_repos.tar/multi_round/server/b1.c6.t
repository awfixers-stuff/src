b1.c6
